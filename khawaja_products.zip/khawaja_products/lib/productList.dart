import 'package:flutter/material.dart';
import 'models.dart';
import 'productTile.dart';
import 'productDetails.dart';

class ProductList extends StatelessWidget {
  final List<Product> products = [
    Product(
      title: '',
      description: 'Color: blue, BMW 3 Series is available in Portimao Blue. BMW 3 Series is also available in 7 colours, namely, Alpine White, Black Sapphire Metallic, Mineral Grey Metallic',
      price: 45000.99,
      imageUrl: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    ),
    Product(
      title: 'Mercedes AMG',
      description: 'Color: Gray, The Mercedes-Benz Group AG (former Daimler AG) is one of the worlds most successful automotive companies. With Mercedes-Benz AG, we are one of the leading global suppliers of high-end passenger cars and premium vans.',
      price: 40000.99,
      imageUrl: 'https://images.pexels.com/photos/112460/pexels-photo-112460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    ),
    Product(
      title: 'Porche x43',
      description: 'Color: Dark Gray, Twin Turbo Engine , 1500HP, 2000NM torque, full package Automatic.',
      price: 63000.10,
      imageUrl: 'https://cdn.pixabay.com/photo/2020/06/22/19/30/automobile-5330343_960_720.jpg',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Product List')),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductTile(
            product: products[index],
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProductDetail(product: products[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
